const Hero = () => {
  return (
    <section id="home" className="min-h-screen flex items-center justify-center bg-gradient-to-b from-blue-50 to-white pt-16">
      <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 py-20 text-center">
        <img
          src="https://images.unsplash.com/photo-1544367567-0f2fcb009e0b?auto=format&fit=crop&q=80&w=200&h=200"
          alt="Ashrei Wellness Logo"
          className="mx-auto w-32 h-32 mb-8 rounded-full shadow-lg"
        />
        <h1 className="text-4xl sm:text-5xl md:text-6xl font-bold text-blue-900 mb-6">
          Ashrei Wellness
        </h1>
        <p className="text-xl sm:text-2xl text-blue-800 mb-8 italic">
          "We help you navigate your journey."
        </p>
        <p className="max-w-2xl mx-auto text-gray-600 mb-12">
          Offering professional mental health services, counseling, and wellness programs
          to help you achieve balance and healing in your life.
        </p>
        <a
          href="#contact"
          className="bg-blue-900 text-white px-8 py-3 rounded-full text-lg font-medium hover:bg-blue-800 transition-colors"
        >
          Start Your Journey
        </a>
      </div>
    </section>
  );
};

export default Hero;