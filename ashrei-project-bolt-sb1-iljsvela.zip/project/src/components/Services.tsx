import { Brain, Heart, Users, Sparkles, BookOpen, Compass } from 'lucide-react';

const services = [
  {
    icon: Brain,
    title: 'Counseling',
    description: 'Professional mental health counseling for individuals and groups',
  },
  {
    icon: Heart,
    title: 'Psychiatry',
    description: 'Expert psychiatric care and medication management',
  },
  {
    icon: BookOpen,
    title: 'Educational Guidance',
    description: 'Career development and educational consulting',
  },
  {
    icon: Sparkles,
    title: 'ADHD Services',
    description: 'Comprehensive ADHD assessment and treatment',
  },
  {
    icon: Users,
    title: 'Family Consultation',
    description: 'Support and guidance for families facing challenges',
  },
  {
    icon: Compass,
    title: 'Wellness Services',
    description: 'Holistic approaches to mental and emotional well-being',
  },
];

const Services = () => {
  return (
    <section id="services" className="py-20 bg-white">
      <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
        <h2 className="text-3xl font-bold text-center text-blue-900 mb-12">
          Our Services
        </h2>
        <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-8">
          {services.map((service) => (
            <div
              key={service.title}
              className="p-6 bg-blue-50 rounded-lg hover:shadow-lg transition-shadow"
            >
              <service.icon className="w-12 h-12 text-blue-900 mb-4" />
              <h3 className="text-xl font-semibold text-blue-900 mb-2">
                {service.title}
              </h3>
              <p className="text-gray-600">{service.description}</p>
            </div>
          ))}
        </div>
      </div>
    </section>
  );
};

export default Services;