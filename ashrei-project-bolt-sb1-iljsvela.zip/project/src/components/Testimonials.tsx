import { useState } from 'react';
import { ChevronLeft, ChevronRight } from 'lucide-react';

const testimonials = [
  {
    text: "Dr. Cassidy helped me develop my career as a Spanish and Russian interpreter. He assisted in shaping my resume, applying for positions, and conducting practice interviews for my current job.",
    author: "A.A."
  },
  {
    text: "Dr. Don is really nice and kind. He helps me figure things out. We talk every week about my activities and goals and how to get along with staff at my group home.",
    author: "Jana M."
  },
  {
    text: "Don Cassidy has served as our Family Consultant at various times over the past 20 years to help us make decisions about two of my adult children and one grandchild. Words cannot adequately describe how grateful I feel for his help.",
    author: "Nancy M."
  }
];

const Testimonials = () => {
  const [currentIndex, setCurrentIndex] = useState(0);

  const next = () => {
    setCurrentIndex((prevIndex) => 
      prevIndex === testimonials.length - 1 ? 0 : prevIndex + 1
    );
  };

  const prev = () => {
    setCurrentIndex((prevIndex) => 
      prevIndex === 0 ? testimonials.length - 1 : prevIndex - 1
    );
  };

  return (
    <section id="testimonials" className="py-20 bg-white">
      <div className="max-w-4xl mx-auto px-4 sm:px-6 lg:px-8">
        <h2 className="text-3xl font-bold text-center text-blue-900 mb-12">
          Client Testimonials
        </h2>
        <div className="relative">
          <div className="flex items-center">
            <button
              onClick={prev}
              className="absolute left-0 transform -translate-x-full text-blue-900 hover:text-blue-700 transition-colors"
            >
              <ChevronLeft size={32} />
            </button>
            <div className="bg-blue-50 p-8 rounded-lg shadow-lg">
              <blockquote className="text-lg text-gray-700 italic mb-4">
                "{testimonials[currentIndex].text}"
              </blockquote>
              <p className="text-right text-blue-900 font-medium">
                - {testimonials[currentIndex].author}
              </p>
            </div>
            <button
              onClick={next}
              className="absolute right-0 transform translate-x-full text-blue-900 hover:text-blue-700 transition-colors"
            >
              <ChevronRight size={32} />
            </button>
          </div>
        </div>
      </div>
    </section>
  );
};

export default Testimonials;